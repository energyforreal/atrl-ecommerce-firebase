// Public config (safe to serve to browser)
window.ATTRAL_PUBLIC = {
  RAZORPAY_KEY_ID: '', // e.g. rzp_live_xxxxxxxxxxxx
  FIREBASE_CONFIG: {
    apiKey: '',
    authDomain: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: ''
  },
  // Local development API endpoints
  API_BASE_URL: 'http://localhost:8000',
  IS_LOCAL_DEV: true
};


