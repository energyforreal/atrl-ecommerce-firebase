(function(){
  // Replace with your Firebase web app config
  const firebaseConfig = (window.ATTRAL_PUBLIC && window.ATTRAL_PUBLIC.FIREBASE_CONFIG) || {
    apiKey: "",
    authDomain: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: "",
    appId: ""
  };

  if (!firebaseConfig.apiKey) { window.AttralFirebase = null; return; }

  // Load Firebase from CDN
  const s1 = document.createElement('script'); s1.src = 'https://www.gstatic.com/firebasejs/10.12.5/firebase-app-compat.js';
  const s2 = document.createElement('script'); s2.src = 'https://www.gstatic.com/firebasejs/10.12.5/firebase-auth-compat.js';
  const s3 = document.createElement('script'); s3.src = 'https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore-compat.js';

  s3.onload = function(){
    const app = firebase.initializeApp(firebaseConfig);
    const auth = firebase.auth();
    const db = firebase.firestore();
    window.AttralFirebase = { app, auth, db };
    // Anonymous sign-in (safe default) so writes have UID
    auth.onAuthStateChanged(function(u){ if(!u){ auth.signInAnonymously().catch(function(){}); } });
  };
  document.head.appendChild(s1);
  document.head.appendChild(s2);
  document.head.appendChild(s3);
})();


