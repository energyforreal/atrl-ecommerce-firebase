(function(){
  const STORAGE_KEYS = { CART: 'attral_cart', REF: 'attral_ref' };

  // Capture ?ref and common UTM params, store for 30 days
  (function captureReferral(){
    try {
      const params = new URLSearchParams(window.location.search);
      const ref = params.get('ref');
      const utm_source = params.get('utm_source');
      const utm_medium = params.get('utm_medium');
      const utm_campaign = params.get('utm_campaign');
      if (ref || utm_source || utm_medium || utm_campaign) {
        const payload = {
          ref: ref || null,
          utm: { source: utm_source || null, medium: utm_medium || null, campaign: utm_campaign || null },
          ts: Date.now()
        };
        localStorage.setItem(STORAGE_KEYS.REF, JSON.stringify(payload));
      }
    } catch (e) { /* no-op */ }
  })();

  function readReferral(){
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.REF);
      if (!raw) return null;
      const data = JSON.parse(raw);
      const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
      if (!data.ts || (Date.now() - data.ts) > THIRTY_DAYS) { localStorage.removeItem(STORAGE_KEYS.REF); return null; }
      return data;
    } catch { return null; }
  }

  function readCart(){
    try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.CART) || '[]'); } catch { return []; }
  }
  function writeCart(items){ localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(items)); }
  function updateHeaderCount(){
    const items = readCart();
    const count = items.reduce((a,i)=>a + (i.quantity||1), 0);
    const el = document.getElementById('cart-count');
    if (el) el.textContent = String(count);
  }

  async function fetchProducts(){
    const res = await fetch('data/products.json');
    if(!res.ok) throw new Error('Failed to load products');
    return res.json();
  }

  function createProductCard(product){
    const card = document.createElement('div');
    card.className = 'card';
    const img = document.createElement('img');
    img.className = 'img';
    img.loading = 'lazy';
    img.src = product.image || 'https://via.placeholder.com/640x480?text=Product';
    img.alt = product.title;
    const body = document.createElement('div');
    body.className = 'body';
    const h = document.createElement('div');
    h.className = 'title';
    h.textContent = product.title;
    const p = document.createElement('div');
    p.className = 'price';
    p.textContent = `₹${product.price}`;
    const actions = document.createElement('div');
    actions.className = 'actions';
    const addBtn = document.createElement('button');
    addBtn.className = 'btn btn-primary';
    addBtn.textContent = 'Add to cart';
    addBtn.onclick = ()=> addToCart(product.id);
    actions.appendChild(addBtn);
    body.append(h,p,actions);
    card.append(img, body);
    return card;
  }

  function addToCart(productId){
    fetchProducts().then(products=>{
      const product = products.find(p=>p.id===productId);
      if(!product) return;
      const items = readCart();
      const existing = items.find(i=>i.id===productId);
      if(existing){ existing.quantity += 1; }
      else { items.push({ id: product.id, title: product.title, price: product.price, image: product.image, quantity: 1 }); }
      writeCart(items);
      updateHeaderCount();
      notify('Added to cart 🛒');
    });
  }

  function renderProductsInto(containerId, products){
    const root = document.getElementById(containerId);
    if(!root) return;
    root.innerHTML = '';
    products.forEach(p=> root.appendChild(createProductCard(p)));
  }

  function renderFeaturedProducts(containerId){
    fetchProducts().then(products=>{
      const featured = products.filter(p=>p.featured).slice(0,4);
      renderProductsInto(containerId, featured);
    }).catch(()=>{
      const root = document.getElementById(containerId);
      if(root) root.textContent = 'Failed to load products.';
    });
  }

  function renderAllProducts(containerId, query){
    fetchProducts().then(products=>{
      let list = products;
      if(query){
        const q = query.toLowerCase();
        list = list.filter(p=> (p.title||'').toLowerCase().includes(q) || (p.description||'').toLowerCase().includes(q));
      }
      renderProductsInto(containerId, list);
    }).catch(()=>{
      const root = document.getElementById(containerId);
      if(root) root.textContent = 'Failed to load products.';
    });
  }

  function renderCart(containerId){
    const root = document.getElementById(containerId);
    if(!root) return;
    const items = readCart();
    root.innerHTML = '';
    if(items.length===0){ root.textContent = 'Your cart is empty.'; return; }
    let total = 0;
    items.forEach(item=>{
      total += item.price * item.quantity;
      const line = document.createElement('div');
      line.className = 'line';
      const meta = document.createElement('div');
      meta.className = 'meta';
      const img = document.createElement('img'); img.src = item.image; img.alt = item.title;
      const title = document.createElement('div'); title.textContent = `${item.title} — ₹${item.price}`;
      meta.append(img, title);
      const qty = document.createElement('div'); qty.className='qty';
      const minus = document.createElement('button'); minus.className='btn'; minus.textContent='-'; minus.onclick=()=> changeQty(item.id,-1,containerId);
      const span = document.createElement('span'); span.textContent = String(item.quantity);
      const plus = document.createElement('button'); plus.className='btn'; plus.textContent='+'; plus.onclick=()=> changeQty(item.id,1,containerId);
      const remove = document.createElement('button'); remove.className='btn'; remove.textContent='Remove'; remove.onclick=()=> removeItem(item.id,containerId);
      qty.append(minus, span, plus, remove);
      line.append(meta, qty);
      root.appendChild(line);
    });
    const summary = document.createElement('div'); summary.className='cart-summary';
    const totalEl = document.createElement('div'); totalEl.textContent = `Total: ₹${total}`;
    const checkout = document.createElement('a'); checkout.href='contact.html'; checkout.className='btn btn-primary'; checkout.textContent='Checkout';
    summary.append(totalEl, checkout);
    root.appendChild(summary);
  }

  function changeQty(productId, delta, containerId){
    const items = readCart();
    const item = items.find(i=>i.id===productId);
    if(!item) return;
    item.quantity += delta;
    if(item.quantity<=0){
      const idx = items.findIndex(i=>i.id===productId);
      items.splice(idx,1);
    }
    writeCart(items);
    updateHeaderCount();
    renderCart(containerId);
  }
  function removeItem(productId, containerId){
    const items = readCart().filter(i=>i.id!==productId);
    writeCart(items);
    updateHeaderCount();
    renderCart(containerId);
  }

  function notify(message){
    alert(message);
  }

  window.Attral = {
    initHeaderCartCount: updateHeaderCount,
    renderFeaturedProducts,
    renderAllProducts,
    renderCart,
    notify,
    calculateCartTotalPaise: function(){
      const items = readCart();
      const total = items.reduce((a,i)=> a + (i.price * i.quantity), 0);
      return Math.round(total * 100);
    },
    onPaymentSuccess: async function(order, response){
      // First verify on server
      try {
        const vres = await fetch('../api/verify.php', { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ order_id: order.id, payment_id: response.razorpay_payment_id, signature: response.razorpay_signature }) });
        const vjson = await vres.json();
        if (!vjson.valid) { alert('Payment verification failed'); return; }
      } catch (e) { alert('Verification error'); return; }

      // Then record order if Firebase configured
      try {
        if (window.AttralFirebase && window.AttralFirebase.db) {
          const { db, auth } = window.AttralFirebase;
          const user = auth.currentUser;
          const items = readCart();
          const total = items.reduce((a,i)=> a + (i.price * i.quantity), 0);
          const referral = readReferral();
          await db.collection('orders').add({
            createdAt: new Date(),
            orderId: order.id,
            paymentId: response.razorpay_payment_id,
            signature: response.razorpay_signature,
            amount: order.amount / 100,
            currency: order.currency,
            items: items,
            uid: user ? user.uid : null,
            ref: referral && referral.ref ? referral.ref : null,
            utm: referral && referral.utm ? referral.utm : null
          });
          localStorage.removeItem('attral_cart');
          updateHeaderCount();
        }
      } catch (e) {}
      alert('Payment successful!');
    }
  };

  // Newsletter Form Handler
  function initializeNewsletterForm() {
    const form = document.getElementById('newsletter-form');
    const submitButton = document.getElementById('newsletter-submit');
    const successMessage = document.getElementById('newsletter-success');
    const errorMessage = document.getElementById('newsletter-error');
    
    if (!form || !submitButton) return;

    form.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      // Get form data
      const formData = new FormData(form);
      const name = formData.get('FIRSTNAME').trim();
      const email = formData.get('EMAIL').trim();
      
      // Basic validation
      if (!name || !email) {
        showMessage(errorMessage, 'Please fill in all fields.');
        return;
      }
      
      if (!isValidEmail(email)) {
        showMessage(errorMessage, 'Please enter a valid email address.');
        return;
      }
      
      // Show loading state
      setLoadingState(true);
      hideMessages();
      
      try {
        // Submit to Brevo
        const response = await fetch(form.action, {
          method: 'POST',
          body: formData,
          headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          }
        });
        
        // Check if submission was successful
        if (response.ok) {
          showMessage(successMessage, 'Welcome aboard! Your free shipping code is on its way!');
          form.reset();
          
          // Track successful signup (optional analytics)
          if (typeof gtag !== 'undefined') {
            gtag('event', 'newsletter_signup', {
              event_category: 'engagement',
              event_label: 'free_shipping_code'
            });
          }
        } else {
          throw new Error('Submission failed');
        }
      } catch (error) {
        console.error('Newsletter submission error:', error);
        showMessage(errorMessage, 'Something went wrong. Please try again or contact support.');
      } finally {
        setLoadingState(false);
      }
    });
    
    function setLoadingState(loading) {
      const buttonText = submitButton.querySelector('.button-text');
      const buttonIcon = submitButton.querySelector('.button-icon');
      const buttonArrow = submitButton.querySelector('.button-arrow');
      const loadingSpinner = submitButton.querySelector('.loading-spinner');
      
      if (loading) {
        submitButton.disabled = true;
        buttonText.style.display = 'none';
        buttonIcon.style.display = 'none';
        buttonArrow.style.display = 'none';
        loadingSpinner.style.display = 'block';
      } else {
        submitButton.disabled = false;
        buttonText.style.display = 'inline';
        buttonIcon.style.display = 'inline';
        buttonArrow.style.display = 'inline';
        loadingSpinner.style.display = 'none';
      }
    }
    
    function showMessage(messageElement, customText = null) {
      hideMessages();
      if (customText && messageElement.querySelector('.message-content p')) {
        messageElement.querySelector('.message-content p').textContent = customText;
      }
      messageElement.style.display = 'flex';
      
      // Auto-hide after 5 seconds
      setTimeout(() => {
        hideMessages();
      }, 5000);
    }
    
    function hideMessages() {
      successMessage.style.display = 'none';
      errorMessage.style.display = 'none';
    }
    
    function isValidEmail(email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    }
    
    // Add input validation feedback
    const inputs = form.querySelectorAll('.form-input');
    inputs.forEach(input => {
      input.addEventListener('blur', function() {
        validateField(input);
      });
      
      input.addEventListener('input', function() {
        // Clear error styling on input
        input.style.borderColor = '';
        const errorMsg = input.parentNode.parentNode.querySelector('.field-error');
        if (errorMsg) errorMsg.remove();
      });
    });
    
    function validateField(input) {
      const value = input.value.trim();
      const isEmail = input.type === 'email';
      const isName = input.name === 'FIRSTNAME';
      
      let isValid = false;
      let errorMessage = '';
      
      if (!value) {
        errorMessage = isName ? 'Name is required' : 'Email is required';
      } else if (isEmail && !isValidEmail(value)) {
        errorMessage = 'Please enter a valid email address';
      } else if (isName && value.length < 2) {
        errorMessage = 'Name must be at least 2 characters';
      } else {
        isValid = true;
      }
      
      if (!isValid) {
        input.style.borderColor = '#ef4444';
        showFieldError(input, errorMessage);
      } else {
        input.style.borderColor = '#10b981';
        hideFieldError(input);
      }
      
      return isValid;
    }
    
    function showFieldError(input, message) {
      hideFieldError(input);
      const errorDiv = document.createElement('div');
      errorDiv.className = 'field-error';
      errorDiv.style.cssText = 'color: #ef4444; font-size: 12px; margin-top: 4px; text-align: left;';
      errorDiv.textContent = message;
      input.parentNode.parentNode.appendChild(errorDiv);
    }
    
    function hideFieldError(input) {
      const errorDiv = input.parentNode.parentNode.querySelector('.field-error');
      if (errorDiv) errorDiv.remove();
    }
  }

  // Initialize newsletter form when DOM is ready
  document.addEventListener('DOMContentLoaded', function() {
    initializeNewsletterForm();
  });

})();


