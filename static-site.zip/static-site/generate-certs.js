const { execSync } = require('child_process');
const fs = require('fs');

console.log('🔐 Generating SSL certificates for local HTTPS testing...');

try {
  // Check if OpenSSL is available
  execSync('openssl version', { stdio: 'ignore' });
  console.log('✅ OpenSSL found, generating certificates...');
  
  // Generate private key
  execSync('openssl genrsa -out server-key.pem 2048', { stdio: 'inherit' });
  
  // Generate certificate
  execSync('openssl req -new -x509 -key server-key.pem -out server-cert.pem -days 365 -subj "/C=IN/ST=Test/L=Test/O=ATTRAL/OU=Dev/CN=localhost"', { stdio: 'inherit' });
  
  console.log('✅ SSL certificates generated successfully!');
} catch (error) {
  console.log('⚠️  OpenSSL not found. Creating self-signed certificates using Node.js...');
  
  // Fallback: Create basic certificates using Node.js crypto
  const crypto = require('crypto');
  const forge = require('node-forge');
  
  // Generate a key pair
  const keys = forge.pki.rsa.generateKeyPair(2048);
  
  // Create a certificate
  const cert = forge.pki.createCertificate();
  cert.publicKey = keys.publicKey;
  cert.serialNumber = '01';
  cert.validity.notBefore = new Date();
  cert.validity.notAfter = new Date();
  cert.validity.notAfter.setFullYear(cert.validity.notBefore.getFullYear() + 1);
  
  const attrs = [{
    name: 'commonName',
    value: 'localhost'
  }, {
    name: 'countryName',
    value: 'IN'
  }, {
    shortName: 'ST',
    value: 'Test'
  }, {
    name: 'localityName',
    value: 'Test'
  }, {
    name: 'organizationName',
    value: 'ATTRAL'
  }, {
    shortName: 'OU',
    value: 'Dev'
  }];
  
  cert.setSubject(attrs);
  cert.setIssuer(attrs);
  cert.sign(keys.privateKey);
  
  // Convert to PEM format
  const pemKey = forge.pki.privateKeyToPem(keys.privateKey);
  const pemCert = forge.pki.certificateToPem(cert);
  
  // Write files
  fs.writeFileSync('server-key.pem', pemKey);
  fs.writeFileSync('server-cert.pem', pemCert);
  
  console.log('✅ SSL certificates generated using Node.js!');
}

console.log('📝 Files created:');
console.log('   - server-key.pem (private key)');
console.log('   - server-cert.pem (certificate)');
console.log('');
console.log('🚀 You can now run: npm run https');
console.log('🌐 Your site will be available at: https://localhost:8443');
console.log('⚠️  Note: You may need to accept the self-signed certificate in your browser');
