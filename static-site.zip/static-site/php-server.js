const { spawn } = require('child_process');
const path = require('path');

// Start PHP built-in server for API endpoints
const phpServer = spawn('php', ['-S', 'localhost:8000', '-t', '../api'], {
  cwd: path.join(__dirname, '..'),
  stdio: 'inherit'
});

console.log('🐘 PHP Server starting at http://localhost:8000');
console.log('📁 Serving API files from ../api directory');
console.log('🔗 API endpoints will be available at:');
console.log('   - http://localhost:8000/create_order.php');
console.log('   - http://localhost:8000/verify.php');
console.log('   - http://localhost:8000/webhook.php');

phpServer.on('error', (err) => {
  console.error('❌ PHP Server error:', err);
  console.log('💡 Make sure PHP is installed and available in your PATH');
});

process.on('SIGINT', () => {
  console.log('\n🛑 Stopping PHP server...');
  phpServer.kill();
  process.exit();
});
